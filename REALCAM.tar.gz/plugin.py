# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.config import config, ConfigSubsection, ConfigText, ConfigSelection
from Screens.MessageBox import MessageBox
import subprocess
import re
import os
import base64
from enigma import gRGB, eTimer
from twisted.web.client import getPage

# ---
# القسم 1: تعريف الثوابت والإعدادات
# ---

# تعريف إعدادات البلجن
config.plugins.REALCAM = ConfigSubsection()
config.plugins.REALCAM.username = ConfigText(default="", fixed_size=False)
config.plugins.REALCAM.password = ConfigText(default="", fixed_size=False)
config.plugins.REALCAM.protocol = ConfigSelection(default="cccam", choices=[("cccam", "CCCam"), ("newcamd", "Newcamd")])
config.plugins.REALCAM.destination = ConfigSelection(default="oscam", choices=[("oscam", "OSCam"), ("ncam", "NCam")])

# تعريف مسارات الملفات ومعلومات السيرفر الثابتة
OSCAM_PATH = "/etc/tuxbox/config/oscam.server"
NCAM_PATH = "/etc/tuxbox/config/ncam.server"
INSTALLER_PATH = "/tmp/installer.sh"

CC_HOST = "realcam.site"
CC_PORT = "11130"
NC_HOST = "realcam.site"
NC_PORT = "11131"
NC_DESKEY = "0102030405060708091011121314"

# بورت واجهة الويب للأوسكام الافتراضي
OSCAM_WEB_PORT = 8888 

# ---
# القسم 2: شاشة البلجن الرئيسية
# ---

class REALCAMScreen(Screen):
    # تعريف رقم الإصدار ومسار ملف التحديث
    CURRENT_VERSION = "1.2"
    VERSION_URL = "https://raw.githubusercontent.com/sky-info1/realcam/main/version.txt"
    INSTALLER_URL = "https://raw.githubusercontent.com/sky-info1/realcam/main/installer.sh"

    skin = """
    <screen name="REALCAMScreen" position="center,center" size="1150,850" title="REALCAM V1.2" backgroundColor="#1A1A1A">

        <eLabel position="20,20" size="1110,810" backgroundColor="#2C2C2C" zPosition="-1" />
        
        <widget name="title_info_label" position="30,30" size="1090,90" font="Regular;28" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#3A3A3A" transparent="0" />
        
        <eLabel position="20,130" size="1110,2" backgroundColor="#FFD700" />
        <eLabel position="20,700" size="1110,2" backgroundColor="#FFD700" /> 

        <widget name="username_label" position="60,160" size="220,50" font="Regular;28" halign="left" valign="center" foregroundColor="#FFD700" transparent="1" />
        <widget name="username_value" position="300,160" size="800,50" font="Regular;28" halign="left" valign="center" transparent="1" backgroundColor="#3A3A3A" />

        <widget name="password_label" position="60,230" size="220,50" font="Regular;28" halign="left" valign="center" foregroundColor="#FFD700" transparent="1" />
        <widget name="password_value" position="300,230" size="800,50" font="Regular;28" halign="left" valign="center" transparent="1" backgroundColor="#3A3A3A" />

        <widget name="protocol_label" position="60,300" size="220,50" font="Regular;28" halign="left" valign="center" foregroundColor="#FFD700" transparent="1" />
        <widget name="protocol_value" position="300,300" size="800,50" font="Regular;28" halign="left" valign="center" transparent="1" backgroundColor="#3A3A3A" />

        <widget name="destination_label" position="60,370" size="220,50" font="Regular;28" halign="left" valign="center" foregroundColor="#FFD700" transparent="1" />
        <widget name="destination_value" position="300,370" size="800,50" font="Regular;28" halign="left" valign="center" transparent="1" backgroundColor="#3A3A3A" />

        <widget name="server_state_label" position="60,440" size="220,50" font="Regular;28" halign="left" valign="center" foregroundColor="#FFD700" transparent="1" />
        <widget name="status_led" position="300,440" size="40,50" font="Regular;35" halign="center" valign="center" transparent="1" />
        <widget name="server_state_value" position="350,440" size="750,50" font="Regular;28" halign="left" valign="center" transparent="1" backgroundColor="#3A3A3A" />

        <widget name="update_button_label" position="60,520" size="1070,50" font="Regular;28" halign="center" valign="center" foregroundColor="#FFD700" transparent="1" />
        <widget name="status_label" position="60,580" size="1070,40" font="Regular;24" halign="center" valign="center" transparent="1" />
        
        <widget name="version_label" position="60,640" size="500,40" font="Regular;24" halign="left" valign="center" foregroundColor="#CCCCCC" transparent="1" />
        <widget name="update_status_label" position="610,640" size="500,40" font="Regular;24" halign="right" valign="center" foregroundColor="#CCCCCC" transparent="1" />
        
        <widget name="key_yellow" position="150,730" size="200,60" font="Regular;30" halign="center" valign="center" backgroundColor="#A08500" transparent="0" foregroundColor="#FFFFFF" text="Restart" />
        <widget name="key_blue" position="380,730" size="200,60" font="Regular;30" halign="center" valign="center" backgroundColor="#000080" transparent="0" foregroundColor="#FFFFFF" text="Clear" />
        <widget name="key_red" position="610,730" size="200,60" font="Regular;30" halign="center" valign="center" backgroundColor="#9F1313" transparent="0" foregroundColor="#FFFFFF" text="Delete" />
        <widget name="key_green" position="840,730" size="200,60" font="Regular;30" halign="center" valign="center" backgroundColor="#1F771F" transparent="0" foregroundColor="#FFFFFF" text="Save" />

    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        self.temp_username = config.plugins.REALCAM.username.value
        self.temp_password = config.plugins.REALCAM.password.value

        self["key_red"] = Label("Delete")
        self["key_green"] = Label("Save")
        self["key_yellow"] = Label("Restart")
        self["key_blue"] = Label("Clear")
        self["status_label"] = Label("")
        
        self["title_info_label"] = Label(
            "RealCam 1.2 developed by skyinfo\nFor subscription contact via TELEGRAM: @skyinfotv"
        )
        
        self["username_label"] = Label("Username:")
        self["password_label"] = Label("Password:")
        self["protocol_label"] = Label("Protocol:")
        self["destination_label"] = Label("Destination:")
        self["server_state_label"] = Label("Server Status:")
        
        self["username_value"] = Label(self.temp_username)
        self["password_value"] = Label(self.temp_password)
        self["protocol_value"] = Label(config.plugins.REALCAM.protocol.value)
        self["destination_value"] = Label(config.plugins.REALCAM.destination.value)
        
        self["status_led"] = Label("●")
        self["server_state_value"] = Label("Checking...")

        self["version_label"] = Label("Current Version: %s" % self.CURRENT_VERSION)
        self["update_status_label"] = Label("")
        
        self["update_button_label"] = Label("Check for Updates")

        self["actions"] = ActionMap(
            [
                "OkCancelActions",
                "ColorActions",
                "DirectionActions",
                "MenuActions",
                "NumberActions",
                "EPGAction",
            ],
            {
                "ok": self.keyOk,
                "cancel": self.close,
                "green": self.saveConfig,
                "red": self.keyRed, 
                "yellow": self.restartSoftcam,
                "blue": self.clearSelectedField,
                "up": self.keyUp,
                "down": self.keyDown,
                "left": self.keyLeft,
                "right": self.keyRight,
                "0": lambda: self.keyNumber("0"),
                "1": lambda: self.keyNumber("1"),
                "2": lambda: self.keyNumber("2"),
                "3": lambda: self.keyNumber("3"),
                "4": lambda: self.keyNumber("4"),
                "5": lambda: self.keyNumber("5"),
                "6": lambda: self.keyNumber("6"),
                "7": lambda: self.keyNumber("7"),
                "8": lambda: self.keyNumber("8"),
                "9": lambda: self.keyNumber("9"),
                "epg": self.keyBackspace,
            },
            -1,
        )
        
        self.config_items = ["username", "password", "protocol", "destination", "update_button"]
        self.current_focus_index = 0
        self.onLayoutFinish.append(self.updateFocus)

        self.flickerTimer = eTimer()
        self.flickerTimer.callback.append(self.flickerEffect)
        self.flicker_on = False

        self.checkServerTimer = eTimer()
        self.checkServerTimer.callback.append(self.check_oscam_status)
        self.onLayoutFinish.append(self.startServerCheck)

    def startServerCheck(self):
        self.checkServerTimer.start(2000, True)

    def check_oscam_status(self):
        destination = config.plugins.REALCAM.destination.value
        conf_path = "/etc/tuxbox/config/oscam.conf" if destination == "oscam" else "/etc/tuxbox/config/ncam.conf"
        
        port = "8888" if destination == "oscam" else "8181"
        user = ""
        pwd = ""
        
        # قراءة إعدادات الأوسكام أو النيوكامد من الملف مباشرة
        try:
            with open(conf_path, 'r') as f:
                content = f.read()
                webif_match = re.search(r'\[webif\](.*?)(\[|$)', content, re.DOTALL | re.IGNORECASE)
                if webif_match:
                    w_block = webif_match.group(1)
                    p_m = re.search(r'httpport\s*=\s*\+?([0-9]+)', w_block, re.IGNORECASE)
                    if p_m: port = p_m.group(1)
                    u_m = re.search(r'httpuser\s*=\s*([^\s]+)', w_block, re.IGNORECASE)
                    if u_m: user = u_m.group(1)
                    pw_m = re.search(r'httppwd\s*=\s*([^\s]+)', w_block, re.IGNORECASE)
                    if pw_m: pwd = pw_m.group(1)
        except Exception:
            pass

        # استخدام الصفحة الرئيسية status.html لأنها الأضمن في جميع النسخ
        url = "http://127.0.0.1:%s/status.html" % port
        headers = {}
        
        if user and pwd:
            auth_string = "%s:%s" % (user, pwd)
            base64_bytes = base64.b64encode(auth_string.encode("utf-8"))
            headers[b"Authorization"] = [b"Basic " + base64_bytes]

        d = getPage(url.encode("utf-8"), headers=headers, timeout=3)
        d.addCallback(self.parse_oscam_xml).addErrback(self.oscam_error)

    def parse_oscam_xml(self, data):
        try:
            data_str = data.decode("utf-8", errors="ignore").upper()
            protocol = config.plugins.REALCAM.protocol.value
            
            target_1 = "REALCAM C1" if protocol == "cccam" else "REALCAM N1"
            target_2 = "REALCAM_C1" if protocol == "cccam" else "REALCAM_N1"
            
            found = False
            status_text = "OFF"
            
            # قراءة جداول HTML والبحث عن الريدر ديالك
            rows = re.findall(r'<TR.*?</TR>', data_str, re.DOTALL)
            for row in rows:
                if target_1.upper() in row or target_2.upper() in row:
                    found = True
                    if "CONNECTED" in row or "CARDOK" in row:
                        status_text = "CONNECTED"
                    elif "NEEDINIT" in row:
                        status_text = "NEEDINIT"
                    elif "ERROR" in row:
                        status_text = "ERROR"
                    elif "OFF" in row:
                        status_text = "OFF"
                    else:
                        status_text = "UNKNOWN"
                    break

            if "401 UNAUTHORIZED" in data_str:
                self.set_status_display("WebIF Auth Error", 0xFFA500) # برتقالي
                self.checkServerTimer.start(5000, True)
                return

            if found:
                if status_text in ["CONNECTED", "CARDOK"]:
                    self.set_status_display("Online", 0x00FF00) # أخضر
                else:
                    self.set_status_display("Offline (%s)" % status_text, 0xFF0000) # أحمر
            else:
                self.set_status_display("Offline (Not Found)", 0xFF0000)
                
        except Exception as e:
            self.set_status_display("Parse Error", 0x808080)
        
        self.checkServerTimer.start(5000, True)

    def oscam_error(self, error):
        self.set_status_display("WebIF Offline", 0xFF0000)
        self.checkServerTimer.start(5000, True)

    def set_status_display(self, text, color_rgb):
        self["server_state_value"].setText(text)
        if self["status_led"].instance:
            self["status_led"].instance.setForegroundColor(gRGB(color_rgb))
        if self["server_state_value"].instance:
            self["server_state_value"].instance.setForegroundColor(gRGB(color_rgb))

    def updateFocus(self):
        gold_color = gRGB(0xFFD700)
        yellow_color = gRGB(0xFFFFFF00)
        
        self.flickerTimer.stop()
        self.flicker_on = False
        
        for item_name in self.config_items:
            if item_name == "update_button":
                label_widget = self["update_button_label"]
                if label_widget and label_widget.instance:
                    label_widget.instance.setForegroundColor(gold_color)
            else:
                label_widget = self["{}_label".format(item_name)]
                value_widget = self["{}_value".format(item_name)]
                if label_widget and label_widget.instance:
                    label_widget.instance.setForegroundColor(gold_color)
                if value_widget and value_widget.instance:
                    value_widget.instance.setForegroundColor(gold_color)
                    
        current_item = self.config_items[self.current_focus_index]
        if current_item == "update_button":
            label_widget = self["update_button_label"]
            if label_widget and label_widget.instance:
                label_widget.instance.setForegroundColor(yellow_color)
        else:
            label_widget = self["{}_label".format(current_item)]
            value_widget = self["{}_value".format(current_item)]
            if label_widget and label_widget.instance:
                label_widget.instance.setForegroundColor(yellow_color)
            if value_widget and value_widget.instance:
                value_widget.instance.setForegroundColor(yellow_color)
            
        self.flickerTimer.start(250, True)

    def flickerEffect(self):
        gold_color = gRGB(0xFFD700)
        yellow_color = gRGB(0xFFFFFF00)
        
        self.flicker_on = not self.flicker_on
        
        current_item = self.config_items[self.current_focus_index]
        
        if current_item == "update_button":
            label_widget = self["update_button_label"]
            if self.flicker_on:
                if label_widget and label_widget.instance:
                    label_widget.instance.setForegroundColor(gold_color)
            else:
                if label_widget and label_widget.instance:
                    label_widget.instance.setForegroundColor(yellow_color)
        else:
            label_widget = self["{}_label".format(current_item)]
            value_widget = self["{}_value".format(current_item)]
            if self.flicker_on:
                if label_widget and label_widget.instance:
                    label_widget.instance.setForegroundColor(gold_color)
                if value_widget and value_widget.instance:
                    value_widget.instance.setForegroundColor(gold_color)
            else:
                if label_widget and label_widget.instance:
                    label_widget.instance.setForegroundColor(yellow_color)
                if value_widget and value_widget.instance:
                    value_widget.instance.setForegroundColor(yellow_color)

        self.flickerTimer.start(250, True)

    def keyUp(self):
        if self.current_focus_index > 0:
            self.current_focus_index -= 1
            self.updateFocus()

    def keyDown(self):
        if self.current_focus_index < len(self.config_items) - 1:
            self.current_focus_index += 1
            self.updateFocus()
            
    def keyLeft(self):
        current_item = self.config_items[self.current_focus_index]
        if current_item == "protocol":
            config.plugins.REALCAM.protocol.handleKey(0, 5)
            self["protocol_value"].setText(config.plugins.REALCAM.protocol.value)
            self.startServerCheck()
        elif current_item == "destination":
            config.plugins.REALCAM.destination.handleKey(0, 5)
            self["destination_value"].setText(config.plugins.REALCAM.destination.value)

    def keyRight(self):
        current_item = self.config_items[self.current_focus_index]
        if current_item == "protocol":
            config.plugins.REALCAM.protocol.handleKey(0, 6)
            self["protocol_value"].setText(config.plugins.REALCAM.protocol.value)
            self.startServerCheck()
        elif current_item == "destination":
            config.plugins.REALCAM.destination.handleKey(0, 6)
            self["destination_value"].setText(config.plugins.REALCAM.destination.value)

    def keyNumber(self, number):
        current_item = self.config_items[self.current_focus_index]
        if current_item == "username":
            self.temp_username += number
            self.update_value_label(current_item, self.temp_username)
        elif current_item == "password":
            self.temp_password += number
            self.update_value_label(current_item, self.temp_password)
    
    def keyRed(self):
        self.keyBackspace()
    
    def keyBackspace(self):
        current_item = self.config_items[self.current_focus_index]
        if current_item == "username" and len(self.temp_username) > 0:
            self.temp_username = self.temp_username[:-1]
            self.update_value_label(current_item, self.temp_username)
        elif current_item == "password" and len(self.temp_password) > 0:
            self.temp_password = self.temp_password[:-1]
            self.update_value_label(current_item, self.temp_password)

    def update_value_label(self, item_name, value):
        if item_name == "username":
            self["username_value"].setText(value)
        elif item_name == "password":
            self["password_value"].setText(value)

    def keyOk(self):
        current_item = self.config_items[self.current_focus_index]
        if current_item in ["protocol", "destination"]:
            self.keyRight()
        elif current_item == "update_button":
            self.checkForUpdates()

    def saveConfig(self):
        config.plugins.REALCAM.username.value = self.temp_username
        config.plugins.REALCAM.password.value = self.temp_password

        for item in self.config_items:
            if item not in ["update_button"]:
                getattr(config.plugins.REALCAM, item).save()

        username = config.plugins.REALCAM.username.value
        password = config.plugins.REALCAM.password.value
        protocol = config.plugins.REALCAM.protocol.value
        destination = config.plugins.REALCAM.destination.value
        
        file_path = ""
        if destination == "oscam":
            file_path = OSCAM_PATH
        elif destination == "ncam":
            file_path = NCAM_PATH

        if not username or not password:
            self.session.open(MessageBox, "Username and Password cannot be empty!", MessageBox.TYPE_INFO)
            return

        reader_number = 1
        group_number = 1
        
        if protocol == "cccam":
            reader_line = self.generate_cccam_reader(username, password, reader_number, group_number)
        else:
            reader_line = self.generate_newcamd_reader(username, password, reader_number, group_number)

        self.add_or_replace_reader(file_path, reader_line, protocol)
        self.session.open(MessageBox, "Configuration saved successfully!\nExisting reader was replaced, if any.\nPlease restart your Softcam to apply changes.", MessageBox.TYPE_INFO, timeout=5)

    def clearSelectedField(self):
        current_item = self.config_items[self.current_focus_index]
        if current_item == "username":
            self.temp_username = ""
            self["username_value"].setText("")
            message = "Username field cleared."
        elif current_item == "password":
            self.temp_password = ""
            self["password_value"].setText("")
            message = "Password field cleared."
        else:
            message = "Cannot clear this field. It is for display only."
            
        self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=3)
        
    def restartSoftcam(self):
        softcam_command = "/etc/init.d/softcam restart"
        try:
            subprocess.run(softcam_command, shell=True, check=True)
            self.session.open(MessageBox, "Softcam restarted successfully!", MessageBox.TYPE_INFO, timeout=3)
            self.startServerCheck()
        except subprocess.CalledProcessError as e:
            self.session.open(MessageBox, f"Failed to restart softcam: {e}", MessageBox.TYPE_ERROR)
        except FileNotFoundError:
            self.session.open(MessageBox, "Softcam command not found. Please check your system configuration.", MessageBox.TYPE_ERROR)
            
    def close(self):
        self.flickerTimer.stop()
        if self.temp_username != config.plugins.REALCAM.username.value or \
           self.temp_password != config.plugins.REALCAM.password.value:
            self.session.openWithCallback(self.exit_confirm, MessageBox, "Changes not saved. Do you want to exit without saving?", MessageBox.TYPE_YESNO)
        else:
            Screen.close(self)
        
    def exit_confirm(self, result):
        if result:
            Screen.close(self)

    def checkForUpdates(self):
        self["update_status_label"].setText("Checking for updates...")
        d = getPage(self.VERSION_URL.encode("utf-8"))
        d.addCallback(self.updateCheckCallback).addErrback(self.updateCheckError)

    def updateCheckCallback(self, data):
        latest_version = data.decode("utf-8").strip()
        if latest_version > self.CURRENT_VERSION:
            message = f"New version {latest_version} is available. Do you want to update now?"
            self.session.openWithCallback(self.update_confirmation_callback, MessageBox, message, MessageBox.TYPE_YESNO)
        else:
            self["update_status_label"].setText("No updates available.")

    def update_confirmation_callback(self, result):
        if result:
            self.performUpdate()
        else:
            self["update_status_label"].setText("Update cancelled by user.")

    def updateCheckError(self, error):
        self["update_status_label"].setText("Update check failed. Check your network connection.")

    def performUpdate(self):
        self["update_status_label"].setText("Downloading and installing update...")
        d = getPage(self.INSTALLER_URL.encode("utf-8"))
        d.addCallback(self.downloadInstallerCallback).addErrback(self.downloadInstallerError)

    def downloadInstallerCallback(self, data):
        try:
            with open(INSTALLER_PATH, "wb") as f:
                f.write(data)
            os.chmod(INSTALLER_PATH, 0o755) 
            self.executeInstaller()
        except Exception as e:
            self.session.open(MessageBox, f"Failed to save installer script: {e}", MessageBox.TYPE_ERROR)

    def downloadInstallerError(self, error):
        self.session.open(MessageBox, "Failed to download installer script. Check your internet connection.", MessageBox.TYPE_ERROR)

    def executeInstaller(self):
        self["update_status_label"].setText("Installing update, please wait...")
        try:
            process = subprocess.run([INSTALLER_PATH], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            self.session.open(MessageBox, "Update successful! Please reboot your receiver to complete the process.", MessageBox.TYPE_INFO)
            self["update_status_label"].setText("Update finished. Reboot to apply.")
        except subprocess.CalledProcessError as e:
            self.session.open(MessageBox, f"Update failed! Error: {e.stderr}", MessageBox.TYPE_ERROR)
        except FileNotFoundError:
            self.session.open(MessageBox, "Installer script not found.", MessageBox.TYPE_ERROR)
        except Exception as e:
            self.session.open(MessageBox, f"An unexpected error occurred during update: {e}", MessageBox.TYPE_ERROR)

    def add_or_replace_reader(self, file_path, new_reader, protocol):
        prefix = "REALCAM_C" if protocol == "cccam" else "REALCAM_N"
        reader_label_to_find = f"label = {prefix}1"
        reader_block_start = "[reader]"

        try:
            with open(file_path, 'r') as f:
                content = f.read()
        except FileNotFoundError:
            with open(file_path, 'w') as f:
                f.write(new_reader)
            return

        regex = r'(\[reader\].*?label\s*=\s*' + prefix + r'1.*?)(?=\[reader\]|\Z)'
        match = re.search(regex, content, re.DOTALL | re.IGNORECASE)

        if match:
            old_reader_block = match.group(1)
            content = content.replace(old_reader_block, new_reader)
        else:
            content += new_reader

        with open(file_path, 'w') as f:
            f.write(content)

    def generate_cccam_reader(self, username, password, reader_number, group_number):
        reader_label = f"REALCAM C{reader_number}"
        return f"""
[reader]
label = {reader_label}
enable = 1
protocol = cccam
device = {CC_HOST},{CC_PORT}
user = {username}
password = {password}
inactivitytimeout             = 30
cccversion                    = 2.3.2
disablecrccws                 = 1
disableserverfilter           = 1
keepalive                     = 1
cacheex                       = 1
cacheex_allow_request         = 1
cacheex_drop_csp              = 1
cacheex_allow_filter          = 0
group                         = {group_number}
uniq                          = 1
dropbadcws                    = 1
connectoninit                 = 1
reconnecttimeout              = 2

"""

    def generate_newcamd_reader(self, username, password, reader_number, group_number):
        reader_label = f"REALCAM N{reader_number}"
        return f"""
[reader]
label = {reader_label}
enable = 1
protocol = newcamd 
device = {NC_HOST},{NC_PORT}
user = {username}
password = {password}
deskey = {NC_DESKEY}
inactivitytimeout             = 30
disablecrccws                 = 1
disableserverfilter           = 1
cacheex                       = 1
cacheex_allow_request         = 1
cacheex_drop_csp              = 1
cacheex_allow_filter          = 0
group                         = {group_number}
uniq                          = 1
dropbadcws                    = 1
connectoninit                 = 1
reconnecttimeout              = 2

"""

# ---
# القسم 3: تعريف البلجن
# ---

def main(session, **kwargs):
    session.open(REALCAMScreen)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="REALCAM",
            description="Configure your CCCam/Newcamd reader and manage softcams",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            fnc=main,
            icon="plugin.png"
        )
    ]